<?php
    $Username =$_GET['Username'];
    $Email_Address =$_GET['Email_Address'];
    $password =$_GET['password'];
    $confirm_password =$_GET['confirm_password'];
    
    // $conn =new mysqli('localhost','root','','login');
    // if($conn->connect_error){
    //     die('Connection Failed :'.$conn->connect_error);
    // }else{
    //     $stmt =$conn->prepare("insert into login(Email_Address,password,confirm_password) values('admin@gmail.com', 'password')");
    //     // $stmt->bind_param("ssss",$Username,$Email_Address,$password,$confirm_password);
    //     $stmt->execute();
    //     echo"new user added...";
    //     $stmt->close();
    //     $stmt->close();
    // }

    $conn = mysqli_connect("localhost","root","","user");
    
    $query = mysqli_query($conn, "insert into login(username, Email_Address, password) values('$Username' ,'$Email_Address', '$password')");

    // $row = mysqli_fetch_array($query);
?>
