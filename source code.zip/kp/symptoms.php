<!DOCTYPE html>
<html>
<head>
	<title>Symptom Checker</title>
	<style>
		body {
			background-color: #f2f2f2;
			font-family: Arial, sans-serif;
      background-image: url("drlogo2.jpg");
                background-repeat: no-repeat;
                width: 100%;
                /* Full height */
                height: 100%;

                /* Center and scale the image nicely */
                background-position: center;
                background-repeat: no-repeat;
                background-size: cover;

		}
    nav{
    position: fixed;
    background: #7568c0;
    width: 100%;
    padding: 10px 0;
    z-index: 12;
  }
		nav .menu{
    max-width: 1250px;
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 20px;
  }
  .menu .logo a{
    width: 1px;
    height: 1px;
    display: inline-flex;
    margin-left:1px;
  }
  .menu ul{
    display: inline-flex;
  }
  .menu ul li{
    list-style: none;
    margin-left: 7px;
  }
  .menu ul li:first-child{
    margin-left: 0px;
  }
  .menu ul li a{
    text-decoration: none;
    color: #fff;
    font-size: 18px;
    font-weight: 500;
    padding: 8px 15px;
    border-radius: 5px;
    transition: all 0.3s ease;
  }
  .menu ul li a:hover{
    background: #fff;
    color: rgb(11, 11, 11);
  }

        h1 {
		color: #fff;
		text-align: center;
		font-size: 36px;
		margin-top: 50px;
	}

	form {
		background-color: #f5f1f126;
		border: none;
		border-radius: none;
		padding: 20px;
		margin: 50px auto;
		max-width: 500px;
	}

	label {
		display: block;
		margin-bottom: 10px;
    color:#fff;
	}

	input[type="checkbox"] {
		margin-right: 10px;
	}

	input[type="submit"] {
		background-color: #4CAF50;
		color: #fff;
		border: none;
		padding: 10px 20px;
		border-radius: 5px;
		cursor: pointer;
		margin-top: 20px;
	}

	input[type="submit"]:hover {
		background-color: #3e8e41;
	}
  footer { 
    background-color: linear-gradient(to left, #f5d8d8, #db9fa5, #df3b61);
    padding: 20px;
    text-align: center;
    display: flex;
    justify-content: center;
    
  }

  .footer-field {
    display:"white";
    margin-right: 200px;
    
    text-align: center;
  }
  .footer-field h5 {
      font-size: 30px;
      color: #e74c3c;
      padding-bottom: 8px;
      text-align: start;
      
  }

  .footer-field a {
    display: block;
    margin-bottom: 10px;
    text-decoration: none;
    color: white;
    text-align: start;
    font-size: 15px;
  } 

  .footer-field a:hover {
      color:#e74c3c;
      /* font-weight: bold; */
      text-shadow: 0.2px 0.2px 0.14px #333, -0.2px -0.2px 0.14px #333;
  }  

 .ft {
    background-color: #FFF;
    color: white;
    text-align: flex-start;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-left: 10px;
    padding-right: 10px;
  
  }

  .ft p{
      color:#e74c3c;
      font-style: bold;
      font-weight: bold;
      text-decoration: bold;
     
  }
.social-icons a {
  font-size: 24px;
  color: #333;
  background-color: transparent;
  margin-right: 10px;
  transition: all 0.3s ease-in-out;

}
.social-icons {
    display: flex;
    justify-content: flex-start;
  }
.social-icons a:hover {
    background-color:transparent;
    color: royalblue;
}

.fab.fa-instagram:hover {
  color: #c13584;
}

#agree .agree h1{
    padding-left: 80px;
    color: rgb(10, 185, 10);
    margin: 30px;  
}
#agree .agree h7{
    padding-left: 80px;
    color: rgb(0, 0, 0);
    margin: 30px;  
    font-size: 35px;
  padding-bottom: 10px;
  font-family: Georgia, 'Times New Roman', Times, serif;
}
#agree .agree img{
    padding-left: 80px;
}
#agree .agree p{
    
    width:100%;
    padding-left: 200px;
}
#agree .agree span{
    color: darkgray;
}

</style>

</head>
<body>
	<?php
		session_start();
		if(isset($_SESSION['user_id'])){
			if($_SESSION['user_id'] == 'admin'){
				header("Location: login.php");
				exit;
			}
			
		}
		echo "<center> <h2 style='color: red'> welcome ".$_SESSION['user_id']. "</h2> </center>";
	?>
	<header>
        <nav>
          <div class="menu">
            <div class="logo">
              <img src="logo.png" alt="website logo" width="30%" >
            </div>
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="login.html">login</a></li>
              <li><a href="about.html">About</a></li>
              <li><a href="policy.php">Policy</a></li>
              <li><a href="feedback.php">Feedback</a></li>
            </ul>
          </div>
        </nav>
      </header><br><br><br>
	<h1>Disease Predictor</h1>
	<form action="predict.php" method="GET">
		<label for="symptoms">Select your symptoms:</label><br>
		<input type="checkbox" name="symptoms[]" value="cough">Cough<br>
		<input type="checkbox" name="symptoms[]" value="fever">Fever<br>
		<input type="checkbox" name="symptoms[]" value="headache">Headache<br>
		<input type="checkbox" name="symptoms[]" value="nausea">Nausea<br>
		<input type="checkbox" name="symptoms[]" value="rash">Rash<br>
        <input type="checkbox" name="symptoms[]" value="vomiting">vomiting<br>
        <input type="checkbox" name="symptoms[]" value="diarrhea">Diarrhea<br>
        <input type="checkbox" name="symptoms[]" value="fatigue">Fatigue<br>
        <input type="checkbox" name="symptoms[]" value="joint pain">Joint Pain<br>
        <input type="checkbox" name="symptoms[]" value="abdominal pain">Abdominal Pain<br>
        <input type="checkbox" name="symptoms[]" value="chest pain">Chest Pain<br>
        <input type="checkbox" name="symptoms[]" value="sore throat">Sore Throat<br>
        <input type="checkbox" name="symptoms[]" value="shortness of breath">shortness of breath<br>
        <input type="checkbox" name="symptoms[]" value="swelling">swelling<br>
        <input type="checkbox" name="symptoms[]" value="muscle weakness">muscle weakness<br>
        <input type="checkbox" name="symptoms[]" value="dizziness">dizziness<br>
        <input type="checkbox" name="symptoms[]" value="back pain">back pain<br>
        <input type="checkbox" name="symptoms[]" value="urinary incontinence">urinary incontinence<br>
        <input type="checkbox" name="symptoms[]" value="vision changes">vision changes<br>
        <input type="checkbox" name="symptoms[]" value="memory loss">memory loss<br>
        <input type="checkbox" name="symptoms[]" value="seizures">seizures<br>
        <input type="checkbox" name="symptoms[]" value="speech difficulty">speech difficulty<br>
        <input type="checkbox" name="symptoms[]" value="swollen lymph nodes">swollen lymph nodes<br>
        <input type="checkbox" name="symptoms[]" value="night sweats">night sweats<br>
        <input type="checkbox" name="symptoms[]" value="weight loss">weight loss<br>
        <input type="checkbox" name="symptoms[]" value="weight gain">weigh gain<br>
		<input type="submit" value="Predict disease">
	</form>
  <footer>
      <div class="footer-field">
        <h5>Disease Prediction System</h5>
      <a>Thank you for using our Disease Prediction System website.<br> We hope that you have found it useful in your disease<br> and understanding of various disease</a>
      <a>If you have<br> any feedback or suggestions, please feel free to contact us.<br> We are always looking for ways to improve our website and<br> make it even more helpful for our users.</a><br>
      <a>Stay tuned for updates and new features.<br> Make Yourself A Priority!</a>
      
    </div>
      
    
    <div class="footer-field">
        <h5>Contact</h5>
        <a>Email: DiseasePredictionSystem@gmail.com</a>
        <a>Phone: 4-800-123-4567</a>
        <a>Address: Shree Nagar,<br>
           Muktainager,<br>
           Jalgaon 425 327</a>
    </div>
    
    <div class="footer-field">
        <footer>
        <div class="Disease Prediction System-footer"><br><br><br>
        <a href="index.php">Disease Prediction System</a>
    </div>

  
  </footer>
    
    </footer>
    <div class="ft">
    
    <p>Copyright &copy; 2023 Disease Prediction System</p>
    <div class="social-icons">
    <a href="#">
    <i class="fab fa-twitter"></i>
    </a>
    <a href="#">
    <i class="fab fa-instagram"></i>
    </a>
    <a href="#">
    <i class="fab fa-facebook-f"></i>
    </a>
    </div>
    </div>

</body>
</html>
