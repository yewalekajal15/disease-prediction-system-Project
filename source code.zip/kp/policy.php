<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Disease Prediction System  </title>
        <link rel="stylesheet" href="css/bootstrap.min.css" media="screen" >
        <link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >
        <link rel="stylesheet" type="text/css" href="js/DataTables/datatables.min.css"/>
        <link rel="stylesheet" href="css/main.css" media="screen" >
        <script src="js/modernizr/modernizr.min.js"></script>
        <style> 
             
             body{
                 background-color:white;
                 width:auto;
                 height:auto;
                 margin:30 auto;
             }
             nav{
    position: fixed;
    background: #7568c0;
    width: 100%;
    padding: 10px 0;
    z-index: 12;
  }
  nav .menu{
    max-width: 1250px;
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 20px;
  }
  .menu .logo a{
    width: 1px;
    height: 1px;
    display: inline-flex;
    margin-left:1px;
  }
  .menu ul{
    display: inline-flex;
  }
  .menu ul li{
    list-style: none;
    margin-left: 7px;
  }
  .menu ul li:first-child{
    margin-left: 0px;
  }
  .menu ul li a{
    text-decoration: none;
    color: #fff;
    font-size: 18px;
    font-weight: 500;
    padding: 8px 15px;
    border-radius: 5px;
    transition: all 0.3s ease;
  }
  .menu ul li a:hover{
    background: #fff;
    color: rgb(11, 11, 11);
  }

             .intro-page{
                margin-left: 203px;
               margin-right: 203px;
               margin-top:100px;
             }
             .intro-page h2{
                font-size: 32px;
               font-weight: 900;
               color: #499bea;
             }
             .intro-page p
             {
                color: #071c55;
                font-size: 19px;
                font-weight: 800;
             }

             /*.flex-p {
                display: flex;

flex-wrap: wrap;

align-items: center;
padding-bottom: 38px;
}
             
             .flex-p .image-p{
                flex-basis: 30%;
    max-width: 30%;
    padding: 10px;
             }
.flex-p .content-p {
    flex-basis: 70%;
    max-width: 70%;
    padding: 21px;
    
}
.flex-p .content-p li{
     

}
*/


             .intro-page a{
     background-color: #25dfce;
    font-size: 60x;
    font-weight: 900;
    color: #131001;

}     
 
 


input.larger { 
      width: 20px;
      height: 20px;
}
            .margin-right-20 {
    margin-right: 20px !important;
    display: inline-block;
    position: relative;
    top: 5px;
}
            .label-text {
                cursor: pointer;
            }


                   .intro-page a{
     background-color: #25dfce;
    font-size: 60x;
    font-weight: 900;
    color: #131001;

}     
 
.intro-page button{
   /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#499bea+33,207ce5+67 */
background: #499bea; /* Old browsers */
background: -moz-linear-gradient(top,  #499bea 33%, #207ce5 67%); /* FF3.6-15 */
background: -webkit-linear-gradient(top,  #499bea 33%,#207ce5 67%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom,  #499bea 33%,#207ce5 67%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#499bea', endColorstr='#207ce5',GradientType=0 ); /* IE6-9 */

   
    float: left;
    border-radius: 25px;
    transition:0.5s;
   color:white;

}  
.intro-page button:hover{
   /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#29b8e5+50,bce0ee+90 */
background: #29b8e5; /* Old browsers */
background: -moz-linear-gradient(top,  #29b8e5 50%, #bce0ee 90%); /* FF3.6-15 */
background: -webkit-linear-gradient(top,  #29b8e5 50%,#bce0ee 90%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom,  #29b8e5 50%,#bce0ee 90%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#29b8e5', endColorstr='#bce0ee',GradientType=0 ); /* IE6-9 */

   color:white;
    border-radius: 25px;

} 
footer { 
    background-color: linear-gradient(to left, #f5d8d8, #db9fa5, #df3b61);
    padding: 20px;
    text-align: center;
    display: flex;
    justify-content: center;
    
  }

  .footer-field {
    display:"white";
    margin-right: 200px;
    
    text-align: center;
  }
  .footer-field h5 {
      font-size: 30px;
      color: #e74c3c;
      padding-bottom: 8px;
      text-align: start;
      
  }

  .footer-field a {
    display: block;
    margin-bottom: 10px;
    text-decoration: none;
    color: black;
    text-align: start;
    font-size: 15px;
  } 

  .footer-field a:hover {
      color:#e74c3c;
      /* font-weight: bold; */
      text-shadow: 0.2px 0.2px 0.14px #333, -0.2px -0.2px 0.14px #333;
  }  

 .ft {
    background-color: #FFF;
    color: white;
    text-align: flex-start;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-left: 10px;
    padding-right: 10px;
  
  }

  .ft p{
      color:#e74c3c;
      font-style: bold;
      font-weight: bold;
      text-decoration: bold;
     
  }
.social-icons a {
  font-size: 24px;
  color: #333;
  background-color: transparent;
  margin-right: 10px;
  transition: all 0.3s ease-in-out;

}
.social-icons {
    display: flex;
    justify-content: flex-start;
  }
.social-icons a:hover {
    background-color:transparent;
    color: royalblue;
}

.fab.fa-instagram:hover {
  color: #c13584;
}

#agree .agree h1{
    padding-left: 80px;
    color: rgb(10, 185, 10);
    margin: 30px;  
}
#agree .agree h7{
    padding-left: 80px;
    color: rgb(0, 0, 0);
    margin: 30px;  
    font-size: 35px;
  padding-bottom: 10px;
  font-family: Georgia, 'Times New Roman', Times, serif;
}
#agree .agree img{
    padding-left: 80px;
}
#agree .agree p{
    
    width:100%;
    padding-left: 200px;
}
#agree .agree span{
    color: darkgray;
}

</style>
    </head>
    <body >
      

  <?php //include('link/user-topber.php'); ?> 
  <header>
        <nav>
          <div class="menu">
            <div class="logo">
              <img src="logo.png" alt="website logo" width="30%" >
            </div>
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="login.html">login</a></li>
              <li><a href="about.html">About</a></li>
              <li><a href="policy.php">Policy</a></li>
              <li><a href="feedback.php">Feedback</a></li>
            </ul>
          </div>
        </nav>
      </header>
<br>
        <div class="intro-page" >

        <div class="flex-p">

        
       <div class="content-p">
        <center>
       <div class="image-p">
            <img src="policy.jpg">
        
       </div>
       
           <h2> Terms & Policy </h2>
           <p>Before using the checkup, please read Terms of Service. Remember that : </p>
         <ul> 
             <li>Checkup is not a diagnosis. Checkup is for informational purposes and is not a qualified medical opinion.</li>
             <li>Do not use in emergencies. In case of health emergency, call your local emergency number immediately.</li>
             <li>Your data is safe. Information that you provide is anonymous and not shared with anyone.</li>

        </ul>
        <label class="label-text"><input type="checkbox" id="myCheck" class="larger margin-right-20"> I read and accept Terms of Service and Privacy Policy. </label>
</center>
      </div>


      </div>

     

</div>



</div>




        <!-- /.main-wrapper -->
        <script src="js/jquery/jquery-2.2.4.min.js"></script>
        <script>
            $(function($) {
                
                $("#myCheck").on('click', function(){
                    $("#text").slideToggle();
                });
            });
        </script>
        

<script>
function myFunction() {
  var checkBox = document.getElementById("myCheck");
  var text = document.getElementById("text");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
}
</script>
<footer>
      <div class="footer-field">
        <h5>Disease Prediction System</h5>
      <a>Thank you for using our Disease Prediction System website.<br> We hope that you have found it useful in your disease<br> and understanding of various disease</a>
      <a>If you have<br> any feedback or suggestions, please feel free to contact us.<br> We are always looking for ways to improve our website and<br> make it even more helpful for our users.</a><br>
      <a>Stay tuned for updates and new features.<br> Make Yourself A Priority!</a>
      
    </div>
      
    
    <div class="footer-field">
        <h5>Contact</h5>
        <a>Email: DiseasePredictionSystem@gmail.com</a>
        <a>Phone: 4-800-123-4567</a>
        <a>Address: Shree Nagar,<br>
           Muktainager,<br>
           Jalgaon 425 327</a>
    </div>
    
    <div class="footer-field">
        <footer>
        <div class="Disease Prediction System-footer"><br><br><br><br><br>
        <a href="index.php">Disease Prediction System</a>
    </div>

  </footer>
    
    </footer>
    <div class="ft">
    
    <p>Copyright &copy; 2023 Disease Prediction System</p>
    <div class="social-icons">
    <a href="#">
    <i class="fab fa-twitter"></i>
    </a>
    <a href="#">
    <i class="fab fa-instagram"></i>
    </a>
    <a href="#">
    <i class="fab fa-facebook-f"></i>
    </a>
    </div>
    </div>

    </body>
</html>