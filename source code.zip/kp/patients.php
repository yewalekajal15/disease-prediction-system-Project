<!DOCTYPE html>
<html>
<head>
  <title>Admin Page</title>
  <style>
    body{
                background-image: url("wp2595597.jpg");
                background-repeat: no-repeat;
                width: 100%;
                /* Full height */
                height: 100%;

                /* Center and scale the image nicely */
                background-position: center;
                background-repeat: no-repeat;
                background-size: cover;

                }
    nav{
    position: fixed;
    background: #7568c0;
    width: 100%;
    padding: 10px 0;
    z-index: 12;
  }
  nav .menu{
    max-width: 1250px;
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 20px;
  }
  .menu .logo a{
    width: 1px;
    height: 1px;
    display: inline-flex;
    margin-left:1px;
  }
  .menu ul{
    display: inline-flex;
  }
  .menu ul li{
    list-style: none;
    margin-left: 7px;
  }
  .menu ul li:first-child{
    margin-left: 0px;
  }
  .menu ul li a{
    text-decoration: none;
    color: #fff;
    font-size: 18px;
    font-weight: 500;
    padding: 8px 15px;
    border-radius: 5px;
    transition: all 0.3s ease;
  }
  .menu ul li a:hover{
    background: #fff;
    color: rgb(11, 11, 11);
  }
   
    table {
      border-collapse: collapse;
      width: 100%;
      margin-bottom: 20px;
      font-family:Arial, sans-serif;
      
    }

    th, td {
      padding: 8px;
      text-align: left;
      /*border-bottom: 1px solid #ddd;*/
    }

    th {
      background-color: #f2f2f2;
      font-weight: bold;
    }

    tr:hover {
      background-color: #f5f5f5;
    }
    footer { 
    background-color: linear-gradient(to left, #f5d8d8, #db9fa5, #df3b61);
    padding: 20px;
    text-align: center;
    display: flex;
    justify-content: center;
    
  }

  .footer-field {
    display:"white";
    margin-right: 200px;
    
    text-align: center;
  }
  .footer-field h5 {
      font-size: 30px;
      color: #e74c3c;
      padding-bottom: 8px;
      text-align: start;
      
  }

  .footer-field a {
    display: block;
    margin-bottom: 10px;
    text-decoration: none;
    color: black;
    text-align: start;
    font-size: 15px;
  } 

  .footer-field a:hover {
      color:#e74c3c;
      /* font-weight: bold; */
      text-shadow: 0.2px 0.2px 0.14px #333, -0.2px -0.2px 0.14px #333;
  }  

 .ft {
    background-color: #FFF;
    color: white;
    text-align: flex-start;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-left: 10px;
    padding-right: 10px;
  
  }

  .ft p{
      color:#e74c3c;
      font-style: bold;
      font-weight: bold;
      text-decoration: bold;
     
  }
.social-icons a {
  font-size: 24px;
  color: #333;
  background-color: transparent;
  margin-right: 10px;
  transition: all 0.3s ease-in-out;

}
.social-icons {
    display: flex;
    justify-content: flex-start;
  }
.social-icons a:hover {
    background-color:transparent;
    color: royalblue;
}

.fab.fa-instagram:hover {
  color: #c13584;
}

#agree .agree h1{
    padding-left: 80px;
    color: rgb(10, 185, 10);
    margin: 30px;  
}
#agree .agree h7{
    padding-left: 80px;
    color: rgb(0, 0, 0);
    margin: 30px;  
    font-size: 35px;
  padding-bottom: 10px;
  font-family: Georgia, 'Times New Roman', Times, serif;
}
#agree .agree img{
    padding-left: 80px;
}
#agree .agree p{
    
    width:100%;
    padding-left: 200px;
}
#agree .agree span{
    color: darkgray;
}

  </style>
</head>
<body>
<header>
        <nav>
          <div class="menu">
            <div class="logo">
              <img src="logo.png" alt="website logo" width="30%" >
            </div>
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="login.html">login</a></li>
              <li><a href="about.html">About</a></li>
              <li><a href="policy.php">Policy</a></li>
              <li><a href="feedback.php">Feedback</a></li>
            </ul>
          </div>
        </nav>
      </header><br>
      <br> <br> <br> <br> <br> 
      <center>
  <h1>PATIENTS</h1>
  <table>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <!-- <th>Date of Birth</th> -->
      <th>Address</th>
      <th>Last Check Date</th>
      <th>symptoms</th>
    </tr>
    <?php
      // Connect to the database
      $conn = mysqli_connect("localhost", "root", "", "disease");

      // Check connection
      if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
      }

      // Fetch patient records
      $patients_query = "SELECT * FROM patients";
      $patients_result = mysqli_query($conn, $patients_query);

      // Loop through patients
      while ($patient = mysqli_fetch_assoc($patients_result)) {
        echo "<tr>";
        echo "<td>" . $patient['id'] . "</td>";
        echo "<td>" . $patient['name'] . "</td>";
        echo "<td>" . $patient['address'] . "</td>";
        echo "<td>" . $patient['date'] . "</td>";
        // Fetch diseases for this patient
        $diseases_query = "SELECT disease_name FROM diseases WHERE patient_id = " . $patient['id'];
        $diseases_result = mysqli_query($conn, $diseases_query);
        $disease_list = array();
        while ($disease = mysqli_fetch_assoc($diseases_result)) {
          $disease_list[] = $disease['disease_name'];
        }

        // Output list of diseases
        echo "<td>" . implode(", ", $disease_list) . "</td>";
        echo "</tr>";
      }

      // Close connection
      mysqli_close($conn);
    ?>
  </table>
    </center>
    <footer>
      <div class="footer-field">
        <h5>Disease Prediction System</h5>
      <a>Thank you for using our Disease Prediction System website.<br> We hope that you have found it useful in your disease<br> and understanding of various disease</a>
      <a>If you have<br> any feedback or suggestions, please feel free to contact us.<br> We are always looking for ways to improve our website and<br> make it even more helpful for our users.</a><br>
      <a>Stay tuned for updates and new features.<br> Make Yourself A Priority!</a>
      
    </div>
      
    
    <div class="footer-field">
        <h5>Contact</h5>
        <a>Email: DiseasePredictionSystem@gmail.com</a>
        <a>Phone: 4-800-123-4567</a>
        <a>Address: Shree Nagar,<br>
           Muktainager,<br>
           Jalgaon 425 327</a>
    </div>
    
    <div class="footer-field">
        <footer>
        <div class="Disease Prediction System-footer"><br><br><br><br><br>
        <a href="index.php">Disease Prediction System</a>
    </div>

  </footer>
    
    </footer>
    <div class="ft">
    
    <p>Copyright &copy; 2023 Disease Prediction System</p>
    <div class="social-icons">
    <a href="#">
    <i class="fab fa-twitter"></i>
    </a>
    <a href="#">
    <i class="fab fa-instagram"></i>
    </a>
    <a href="#">
    <i class="fab fa-facebook-f"></i>
    </a>
    </div>
    </div>

</body>
</html>
