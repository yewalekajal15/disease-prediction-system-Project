<?php
session_start();
$email = $_SESSION['user_id'];

// Define the symptoms and their corresponding diseases with weights
$symptom_disease_dict = array(
    'fever' => array('malaria' => 0.4, 'dengue' => 0.3, 'typhoid' => 0.2, 'flu' => 0.1),
    'cough' => array('pneumonia' => 0.5, 'tuberculosis' => 0.3, 'bronchitis' => 0.2),
    'vomiting' => array('gastroenteritis' => 0.4, 'hepatitis A' => 0.3, 'food poisoning' => 0.2, 'migraine' => 0.1),
    'diarrhea' => array('gastroenteritis' => 0.4, 'cholera' => 0.3, 'food poisoning' => 0.2, 'irritable bowel syndrome' => 0.1),
    'headache' => array('migraine' => 0.5, 'meningitis' => 0.3, 'brain tumor' => 0.2),
    'fatigue' => array('anemia' => 0.5, 'hypothyroidism' => 0.3, 'chronic fatigue syndrome' => 0.2),
    'joint pain' => array('arthritis' => 0.5, 'lupus' => 0.3, 'fibromyalgia' => 0.2),
    'abdominal pain' => array('appendicitis' => 0.4, 'gallstones' => 0.3, 'ulcerative colitis' => 0.2, 'pancreatitis' => 0.1),
    'chest pain' => array('heart attack' => 0.5, 'angina' => 0.3, 'pulmonary embolism' => 0.2),
    'rash' => array('eczema' => 0.4, 'psoriasis' => 0.3, 'measles' => 0.2, 'chickenpox' => 0.1),
    'sore throat' => array('streptococcal pharyngitis' => 0.5, 'tonsillitis' => 0.3, 'mononucleosis' => 0.2),
    'shortness of breath' => array('asthma' => 0.5, 'pneumothorax' => 0.3, 'pulmonary edema' => 0.2),
    'swelling' => array('edema' => 0.5, 'lymphedema' => 0.3, 'cellulitis' => 0.2),
    'muscle weakness' => array('myasthenia gravis' => 0.5, 'muscular dystrophy' => 0.3, 'multiple sclerosis' => 0.2),
    'nausea' => array('motion sickness' => 0.4, 'pregnancy' => 0.3, 'migraine' => 0.2, 'anxiety' => 0.1),
    'dizziness' => array('vertigo' => 0.5, 'motion sickness' => 0.3, 'anemia' => 0.2),
    'back pain' => array('lumbar strain' => 0.4, 'herniated disk' => 0.3, 'sciatica' => 0.2, 'ankylosing spondylitis' => 0.1),
    'urinary incontinence' => array('urinary tract infection' => 0.4, 'prostate cancer' => 0.3, 'overactive bladder' => 0.2, 'bladder cancer' => 0.1),
    'vision changes' => array('cataracts' => 0.5, 'glaucoma' => 0.3, 'macular degeneration' => 0.2),
    'memory loss' => array('Alzheimer’s disease' => 0.5, 'dementia' => 0.3, 'traumatic brain injury' => 0.2),
    'seizures' => array('epilepsy' => 0.5, 'brain tumor' => 0.3, 'meningitis' => 0.2),
    'speech difficulty' => array('aphasia' => 0.5, 'stroke' => 0.3, 'brain tumor' => 0.2),
    'swollen lymph nodes' => array('HIV/AIDS' => 0.5, 'lymphoma' => 0.3, 'mononucleosis' => 0.2),
    'night sweats' => array('tuberculosis' => 0.5, 'lymphoma' => 0.3, 'menopause' => 0.2),
    'weight loss' => array('cancer' => 0.5, 'diabetes' => 0.3, 'hyperthyroidism' => 0.2),
    'weight gain' => array('hypothyroidism' => 0.5, 'Cushing’s syndrome' => 0.3, 'polycystic ovary syndrome' => 0.2)
); 

// Get the list of symptoms from the URL parameter
// $symptoms = explode(',', $_GET['symptoms']);
 $symptoms = $_GET['symptoms'];

// Calculate probability scores for each disease based on the symptoms
$prob_scores = array();
foreach ($symptom_disease_dict as $symptom => $diseases) {
    if (in_array($symptom, $symptoms)) {
        foreach ($diseases as $disease => $weight) {
            if (!array_key_exists($disease, $prob_scores)) {
                $prob_scores[$disease] = 0;
            }
            $prob_scores[$disease] += $weight;
        }
    }
}

// Sort the diseases by probability score in descending order
arsort($prob_scores);

$temp = "";
foreach($symptoms as $a){
    // echo $a."<br>";
    $temp = $temp.", ".$a;
}
//getting current date to store in database
$date = date("d/m/y");
include_once 'config.php';
mysqli_query($conn, "update patients set date = '$date' where email = '$email'");
$result = mysqli_query($conn, "select id from patients where email = '$email'");
// $id = $result['id'];
$id_get = mysqli_fetch_assoc($result);
$id = $id_get['id'];
// echo $id;
// mysqli_query($conn, "update diseases SET disease_name = '$temp' where patient_id = $id");
mysqli_query($conn, "insert into diseases(patient_id, disease_name) values($id, '$temp')");
// Print the list of diseases with probability scores
// Print the list of diseases with probability scores
if ($prob_scores) {
    echo '<div style="font-size: 1.2em; font-weight: bold;">Possible diseases:</div>';
    echo '<ul style="list-style: none; padding-left: 0;">';
    foreach ($prob_scores as $disease => $score) {
        echo '<li style="margin-bottom: 10px;">';
        echo '<div style="display: flex; justify-content: space-between; align-items: center;">';
        echo '<div style="flex: 1;">' . $disease . '</div>';
        echo '<div style="flex: 1; text-align: right;">' . round($score * 100) . '%</div>';
        echo '</div>';
        echo '<div style="height: 10px; background-color: #eee; border-radius: 5px; overflow: hidden;">';
        echo '<div style="height: 10px; background-color: #007bff; border-radius: 5px; width: ' . round($score * 100) . '%;"></div>';
        echo '</div>';
        echo '</li>';
    }
    echo '</ul>';
}


?>
