<?php
include_once "config.php";
$name = $_GET['username'];
$email = $_GET['email'];
$address = $_GET['address'];
$password = $_GET['password'];

$result = mysqli_query($conn, "select email from patients where email = '$email'");
if (mysqli_num_rows($result) > 0) {
    // Username already exists, show an error message
    echo "<script> alert('Username already exists. Please choose a different username.'); </script>";
    header("Location: login.php");
}else{
$result = mysqli_query($conn, "insert into patients(name, email, address, password) values('$name', '$email', '$address', '$password')");
echo "<script> alert('Registration successfull'); </script>";
header("Location: login.php");

}
?>