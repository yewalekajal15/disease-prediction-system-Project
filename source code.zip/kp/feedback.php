
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1"> 
        <title>Feedback Form</title>
        <link rel="stylesheet" href="bootstrap.min.css" media="screen" >
        <link rel="stylesheet" href="font-awesome.min.css" media="screen" >
        <link rel="stylesheet" type="text/css" href="datatables.min.css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <link rel="stylesheet" href="form-content.css" media="screen" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
        <link rel="stylesheet" href="form.css" >
        <link rel="stylesheet" href="main.css" media="screen" >
        <script src="modernizr.min.js"></script>
        <script src="js/form.js"></script>
        <style>
             nav{
  position: fixed;
  background: #7568c0;
  width: 100%;
  padding: 10px 0;
  z-index: 12;
}
nav .menu{
  max-width: 1250px;
  margin: auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
}
.menu .logo a{
  width: 1px;
  height: 1px;
  display: inline-flex;
  margin-left:1px;
}
.menu ul{
  display: inline-flex;
}
.menu ul li{
  list-style: none;
  margin-left: 7px;
}
.menu ul li:first-child{
  margin-left: 0px;
}
.menu ul li a{
  text-decoration: none;
  color: #fff;
  font-size: 18px;
  font-weight: 500;
  padding: 8px 15px;
  border-radius: 5px;
  transition: all 0.3s ease;
}
.menu ul li a:hover{
  background: #fff;
  color: rgb(11, 11, 11);
}

        button{
            background-color:black;
            color:black;
        }
        footer { 
    background-color: linear-gradient(to left, #f5d8d8, #db9fa5, #df3b61);
    padding: 20px;
    text-align: center;
    display: flex;
    justify-content: center;
    
  }

  .footer-field {
    display:"white";
    margin-right: 200px;
    
    text-align: center;
  }
  .footer-field h5 {
      font-size: 30px;
      color: #e74c3c;
      padding-bottom: 8px;
      text-align: start;
      
  }

  .footer-field a {
    display: block;
    margin-bottom: 10px;
    text-decoration: none;
    color: black;
    text-align: start;
    font-size: 15px;
  } 

  .footer-field a:hover {
      color:#e74c3c;
      /* font-weight: bold; */
      text-shadow: 0.2px 0.2px 0.14px #333, -0.2px -0.2px 0.14px #333;
  }  

 .ft {
    background-color: #FFF;
    color: white;
    text-align: flex-start;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-left: 10px;
    padding-right: 10px;
  
  }

  .ft p{
      color:#e74c3c;
      font-style: bold;
      font-weight: bold;
      text-decoration: bold;
     
  }
.social-icons a {
  font-size: 24px;
  color: #333;
  background-color: transparent;
  margin-right: 10px;
  transition: all 0.3s ease-in-out;

}
.social-icons {
    display: flex;
    justify-content: flex-start;
  }
.social-icons a:hover {
    background-color:transparent;
    color: royalblue;
}

.fab.fa-instagram:hover {
  color: #c13584;
}

#agree .agree h1{
    padding-left: 80px;
    color: rgb(10, 185, 10);
    margin: 30px;  
}
#agree .agree h7{
    padding-left: 80px;
    color: rgb(0, 0, 0);
    margin: 30px;  
    font-size: 35px;
  padding-bottom: 10px;
  font-family: Georgia, 'Times New Roman', Times, serif;
}
#agree .agree img{
    padding-left: 80px;
}
#agree .agree p{
    
    width:100%;
    padding-left: 200px;
}
#agree .agree span{
    color: darkgray;
}

        </style>

    </head>
    <body >

    <header>
  <nav>
    <div class="menu">
      <div class="logo">
        <img src="logo.png" alt="website logo" width="30%" >
      </div>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="login.html">login</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="policy.php">Policy</a></li>
        <li><a href="feedback.php">Feedback</a></li>
      </ul>
    </div>
  </nav>
</header>
        <div class="main-wrapper">
         

        
        <div class="container">
            <div class="imagebg"></div>
            <div class="row " style="margin-top: 100px">
                <div class="col-md-6 col-md-offset-3 form-container">
                    <h2>FEEDBACK FORM</h2> 
                    <p> Please provide your feedback below: </p>
                    <form role="form" method="post" id="reused_form">
                        <div class="row">
                            <div class="col-sm-12 form-group">
                                <label>How do you rate your overall experience?</label>
                                <p>
                                    <label class="radio-inline">
                                        <input type="radio" name="experience" id="experience" value="bad" required>
                                        Bad 
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="experience" id="experience" value="average" required>
                                        Average 
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="experience" id="experience" value="good" required>
                                        Good 
                                    </label>
                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 form-group">
                                <label for="comments"> Messages:</label>
                                <textarea class="form-control" type="textarea" name="comments" id="comments" placeholder="Your Comments" maxlength="6000" rows="7" required></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label for="name"> Your Name:</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="col-sm-6 form-group">
                                <label for="email"> Email:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 form-group">
                                <button type="submit"  name="submit" id="submit" class="btn btn-lg btn-warning btn-block result-color1" >SEND</button>
                            </div>
                        </div>
                    </form>
                    <div id="success_message" style="width:100%; height:100%; display:none; "> <h3>Posted your feedback successfully!</h3> </div>
                    <div id="error_message" style="width:100%; height:100%; display:none; "> <h3>Error</h3> Sorry, there was an error sending your form. </div>
                </div>
            </div>
        </div>
        </div>
        <footer>
      <div class="footer-field">
        <h5>Disease Prediction System</h5>
      <a>Thank you for using our Disease Prediction System website.<br> We hope that you have found it useful in your disease<br> and understanding of various disease</a>
      <a>If you have<br> any feedback or suggestions, please feel free to contact us.<br> We are always looking for ways to improve our website and<br> make it even more helpful for our users.</a><br>
      <a>Stay tuned for updates and new features.<br> Make Yourself A Priority!</a>
      
    </div>
      
    
    <div class="footer-field">
        <h5>Contact</h5>
        <a>Email: DiseasePredictionSystem@gmail.com</a>
        <a>Phone: 4-800-123-4567</a>
        <a>Address: Shree Nagar,<br>
           Muktainager,<br>
           Jalgaon 425 327</a>
    </div>
    
    <div class="footer-field">
        <footer>
        <div class="Disease Prediction System-footer"><br><br><br><br>
        <a href="index.php">Disease Prediction System</a>
    </div>

  </footer>
    
    </footer>
    <div class="ft">
    
    <p>Copyright &copy; 2023 Disease Prediction System</p>
    <div class="social-icons">
    <a href="#">
    <i class="fab fa-twitter"></i>
    </a>
    <a href="#">
    <i class="fab fa-instagram"></i>
    </a>
    <a href="#">
    <i class="fab fa-facebook-f"></i>
    </a>
    </div>
    </div>

    </body>
</html>
<script>
$(document).ready(function(){
    $('#submit').click(function()){
        var experience=$('#experience').val();
        var comments=$('#comments').val();
        var name=$('#name').val();
        var email=$('#email').val();

        if(name=='' || comments == '' || experience =='' || email == '')
        {
              $('#error_message').html("All Fields are required");

        }
        else 
        {
            $('#error_message').html('');
            $.ajax({
                url:"feedback.php",
                method:"POST",
                data:{experience:experience,comments:comments,name:name,email:email},
                success:function(data){
                    $("form").trigger("reset");
                    $('#success_message').fadeIn().html(data);
                }
            });
        }
    }
})
</script>
<?php
$servername = "localhost"; // replace with your server name
$username = "root"; // replace with your username
$password = ""; // replace with your password
$dbname = "disease"; // replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_POST['name'])) {
  # code...
  $experience = $_POST['experience'];
$comments = $_POST['comments'];
$name = $_POST['name'];
$email = $_POST['email'];
// Prepare and bind statement
$stmt = $conn->prepare("INSERT INTO user_result (experience, comments, name, email) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $experience, $comments, $name, $email);

// Set parameters and execute

$stmt->execute();

echo "<script>alert('Feedback submitted successfully');</script>";

// Close statement and connection
$stmt->close();
$conn->close();
}

?>
