<?php
  session_start(); // start the session

  if(!isset($_SESSION['user_id'])) {
    if (!$_SESSION['user_id' == 'admin']) {
       // if user is not logged in, redirect to login page
       header("Location: login.php");
       exit;
    }
    else{
      echo "welcome admin";
    }
     
  }
  else{
    header("Location: patients.php");
    exit;
  }
  
?>