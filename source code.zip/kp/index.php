<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First page</title>
        <!-- <link rel="stylesheet" href="css/bootstrap.min.css" media="screen"> -->
        <link rel="stylesheet" href="firstpage.css">
        <!-- <link rel="stylesheet" href="css/login.css"> -->
        <!-- <link rel="stylesheet" href="login.css"> -->
        <style>
            button{
                cursor: pointer;
            }

            body{
                background-image: url("firstpage.jpg");
                background-repeat: no-repeat;
                width: 100%;
                /* Full height */
                height: 100%;

                /* Center and scale the image nicely */
                background-position: center;
                background-repeat: no-repeat;
                background-size: cover;

                }
                nav{
    position: fixed;
    background: #7568c0;
    width: 100%;
    padding: 10px 0;
    z-index: 12;
  }
  nav .menu{
    max-width: 1250px;
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 20px;
  }
  .menu .logo a{
    width: 1px;
    height: 1px;
    display: inline-flex;
    margin-left:1px;
  }
  .menu ul{
    display: inline-flex;
  }
  .menu ul li{
    list-style: none;
    margin-left: 7px;
  }
  .menu ul li:first-child{
    margin-left: 0px;
  }
  .menu ul li a{
    text-decoration: none;
    color: #fff;
    font-size: 18px;
    font-weight: 500;
    padding: 8px 15px;
    border-radius: 5px;
    transition: all 0.3s ease;
  }
  .menu ul li a:hover{
    background: #fff;
    color: rgb(11, 11, 11);
  }
  footer { 
    background-color: linear-gradient(to left, #f5d8d8, #db9fa5, #df3b61);
    padding: 20px;
    text-align: center;
    display: flex;
    justify-content: center;
    
  }

  .footer-field {
    display:"white";
    margin-right: 200px;
    
    text-align: center;
  }
  .footer-field h5 {
      font-size: 30px;
      color: #e74c3c;
      padding-bottom: 8px;
      text-align: start;
      
  }

  .footer-field a {
    display: block;
    margin-bottom: 10px;
    text-decoration: none;
    color: white;
    text-align: start;
    font-size: 15px;
  } 

  .footer-field a:hover {
      color:#e74c3c;
      /* font-weight: bold; */
      text-shadow: 0.2px 0.2px 0.14px #333, -0.2px -0.2px 0.14px #333;
  }  

 .ft {
    background-color: #FFF;
    color: white;
    text-align: flex-start;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-left: 10px;
    padding-right: 10px;
  
  }

  .ft p{
      color:#e74c3c;
      font-style: bold;
      font-weight: bold;
      text-decoration: bold;
     
  }
.social-icons a {
  font-size: 24px;
  color: #333;
  background-color: transparent;
  margin-right: 10px;
  transition: all 0.3s ease-in-out;

}
.social-icons {
    display: flex;
    justify-content: flex-start;
  }
.social-icons a:hover {
    background-color:transparent;
    color: royalblue;
}

.fab.fa-instagram:hover {
  color: #c13584;
}

#agree .agree h1{
    padding-left: 80px;
    color: rgb(10, 185, 10);
    margin: 30px;  
}
#agree .agree h7{
    padding-left: 80px;
    color: rgb(0, 0, 0);
    margin: 30px;  
    font-size: 35px;
  padding-bottom: 10px;
  font-family: Georgia, 'Times New Roman', Times, serif;
}
#agree .agree img{
    padding-left: 80px;
}
#agree .agree p{
    
    width:100%;
    padding-left: 200px;
}
#agree .agree span{
    color: darkgray;
}

        </style>
</head>
<body>
<header>
        <nav>
          <div class="menu">
            <div class="logo">
              <img src="logo.png" alt="website logo" width="30%" >
            </div>
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="login.html">login</a></li>
              <li><a href="about.html">About</a></li>
              <li><a href="policy.php">Policy</a></li>
              <li><a href="feedback.php">Feedback</a></li>
            </ul>
          </div>
        </nav>
      </header>
    <section class="container content">
    <div class="homepage">
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <h2>What concerns you about your health today ?</h2>
        <p>Check your symptoms and find out what could be causing them , It's fast , free and anonymous.</p>

        <ul>
            <li><button class="homepage-button" onclick="document.getElementById('id01').style.display='block'" style="width: auto;"><a href="login.php">Login as User</a></button></li>
            <li><button class="homepage-button"><a href="admin.php">Login as Admin</a></button></li>
        </ul>
    </div>
</section>
<footer>
      <div class="footer-field">
        <h5>Disease Prediction System</h5>
      <a>Thank you for using our Disease Prediction System website.<br> We hope that you have found it useful in your disease<br> and understanding of various disease</a>
      <a>If you have<br> any feedback or suggestions, please feel free to contact us.<br> We are always looking for ways to improve our website and<br> make it even more helpful for our users.</a><br>
      <a>Stay tuned for updates and new features.<br> Make Yourself A Priority!</a>
      
    </div>
      
    
    <div class="footer-field">
        <h5>Contact</h5>
        <a>Email: DiseasePredictionSystem@gmail.com</a>
        <a>Phone: 4-800-123-4567</a>
        <a>Address: Shree Nagar,<br>
           Muktainager,<br>
           Jalgaon 425 327</a>
    </div>
    
    <div class="footer-field">
        <footer>
        <div class="Disease Prediction System-footer">
        <a href="index.php">Disease Prediction System</a>
    </div>

  </footer>
    
    </footer>
    <div class="ft">
    
    <p>Copyright &copy; 2023 Disease Prediction System</p>
    <div class="social-icons">
    <a href="#">
    <i class="fab fa-twitter"></i>
    </a>
    <a href="#">
    <i class="fab fa-instagram"></i>
    </a>
    <a href="#">
    <i class="fab fa-facebook-f"></i>
    </a>
    </div>
    </div>

</body>
</html>